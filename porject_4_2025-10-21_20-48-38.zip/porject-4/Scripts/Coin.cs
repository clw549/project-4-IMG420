using Godot;
using System;

public partial class Coin : RigidBody2D
{
	[Export]
	public int value = 1;
	private Area2D _area;
	private GpuParticles2D _particles;
	private Timer _timer;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		base._Ready();
		// this was done since RigidBody has only methods for detecting other rigid bodies
		// BodyEntered += collision; // only works for other rigid bodies.
		//Area2D is necissary 
		_area = GetNode<Area2D>("Area2D");
		_area.BodyEntered += collision;
		_particles = GetNode<GpuParticles2D>("GPUParticles2D");
		_timer = GetNode<Timer>("Timer");
		_timer.Timeout += QueueFree;
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}

	public void collision(Node2D other)
	{
		if (other is Player player)
		{
            GD.Print("coin picked up");
			GetNode<AnimatedSprite2D>("AnimatedSprite2D").Hide();
			SetProcess(false);
			_particles.Show();
			_particles.Emitting = true;
			_timer.Start();
			_area.QueueFree();
		}

	}
}
