using Godot;
using System.Collections.Generic;

/// <summary>
/// A basic player controller for a 2D game.  This script demonstrates simple
/// physics (movement, gravity and jumping), collision handling via CharacterBody2D
/// and playing idle/walk animations on an AnimatedSprite2D child.  To use this
/// script, attach it to a CharacterBody2D node in your scene and add an
/// AnimatedSprite2D and CollisionShape2D as children.  Define the animations
/// "idle" and "walk" in the AnimatedSprite2D's SpriteFrames resource.
/// </summary>
public partial class Player : CharacterBody2D
{

    private Vector2 _knockback;

    // Negative value because in Godot, upward movement has a negative Y component.
    //Player attributes
    [Export]
    public float JumpVelocity = -300f;
    [Export]
    public float Gravity = 800f;
    public float health = 100.0f;
    public int coins = 0;
    [Export]
    public float Speed = 200f;

    //list for things that player is colliding with
    public List<Node2D> areas;

    //signal providers
    private AnimatedSprite2D _anim;
    private Area2D _playerHitbox;
    [Signal]
    public delegate void healthDepleatedEventHandler();
    private Timer _hitCD;

    // UI holders
    private TextureProgressBar _healthBar;
    private Label _coins;

    public override void _Ready()
    {
        _healthBar = GetNode<TextureProgressBar>("healthBar");
        _coins = GetNode<Label>("Camera2D/Control/coins");
        // Cache a reference to the AnimatedSprite2D for switching animations and flipping
        _anim = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
        _playerHitbox = GetNode<Area2D>("Area2D");
        GD.Print(_playerHitbox);
        _playerHitbox.BodyEntered += playerHit;
        _playerHitbox.AreaEntered += playerHit;
        _playerHitbox.BodyExited += playerEndHit;
        _playerHitbox.AreaExited += playerEndHit;
        healthDepleated += playerKilled;

        _knockback = Vector2.Zero;

        _coins.Text = "0";

        areas = new List<Node2D>();
        _hitCD = GetNode<Timer>("Timer");
        _hitCD.Timeout += handleContinuousCollisions;

    }

    public override void _Process(double delta)
    {
        _healthBar.Value = health;
        if (health <= 0)
        {
            EmitSignal(SignalName.healthDepleated);
        }
        // Obtain the current velocity so we can modify it
        Vector2 v = Velocity;

        // Horizontal input: positive for right, negative for left
        float inputX = Input.GetActionStrength("ui_right") - Input.GetActionStrength("ui_left");
        v.X = inputX * Speed;

        // Apply gravity every frame if not on the floor
        v.Y += Gravity * (float)delta;

        // Jump when the player presses the jump action (ui_accept) and the body is on the floor
        if (IsOnFloor() && Input.IsActionPressed("ui_accept"))
        {
            v.Y = JumpVelocity;
        }

        // Assign the modified velocity back to the CharacterBody2D and move
        Velocity = v + _knockback;
        MoveAndSlide();
        _knockback *= .750f;

        // Flip and play animations based on movement
        if (_anim != null)
        {
            if (!IsOnFloor())
            {
                _anim.Play("roll");
            }
            else if (Mathf.Abs(inputX) > 0.01f)
            {
                _anim.FlipH = inputX < 0;
                _anim.Play("run");
            }
            else
            {
                _anim.Play("idle");
            }
        }
        if (Input.IsActionJustPressed("reload"))
        {
            GetTree().ReloadCurrentScene();
        }
    }

    private void playerHit(Node2D area)
    {
        GD.Print(area is Slime);

        GD.Print(area.ToString());
        _hitCD.Start();
        handleCollision(area);

        //catching the hitting slime hitbox or area2D
        if (area.GetParent() is Slime slime2)
        {
            areas.Add(slime2);
        }
        if (area.GetParent() is Coin coin)
        {
            areas.Add(coin);
        }
        else
        {
            areas.Add(area);
        }
    }

    private void playerEndHit(Node2D area)
    {
        areas.Remove(area);
        GD.Print("end hit");
        _hitCD.Stop();
    }

    private void playerKilled()
    {
        GetTree().ReloadCurrentScene();
    }

    private void coinsUpdated()
    {
        _coins.Text = coins.ToString();
    }

    private void handleContinuousCollisions()
    {
        foreach (Node2D area in areas)
        {
            if (area.GlobalPosition.DistanceTo(GlobalPosition)<8)
            handleCollision(area); else areas.Remove(area);
        }
    }

    private void handleCollision(Node2D area)
    {
        if (area is Coin coin)
        {
            coins += coin.value;
            coinsUpdated();
            areas.Remove(area);
        }
        else if (area is Slime slime)
        {
            health -= slime.damage;
            _knockback = (-area.GlobalPosition + GlobalPosition).Normalized() * -Speed;
        }
        else if (area is TileMapLayer tiles)
        {
            // gets the players position and then calculates the tile under 
            Vector2 collisionLoc = GlobalPosition + Vector2.Down * 8;
            Vector2 localPos = tiles.ToLocal(collisionLoc);

            // convert position to tile coordinates
            Vector2I tileCoords = tiles.LocalToMap(localPos);

            // get tile data
            TileData tileData = tiles.GetCellTileData(tileCoords);

            if (tileData != null)
            {
                GD.Print($"Tile at {tileCoords} has tile data.");

                Variant bouncyValue = tileData.GetCustomData("bouncy");
                if (bouncyValue.VariantType == Variant.Type.Bool && (bool)bouncyValue)
                {
                    _knockback = Vector2.Up * Speed;
                }

                Variant damageValue = tileData.GetCustomData("damage");
                if (damageValue.VariantType == Variant.Type.Int)
                {
                    health -= (int)damageValue;
                }

                Variant goalValue = tileData.GetCustomData("goal");
                if (goalValue.VariantType == Variant.Type.Bool && (bool)goalValue)
                {
                    GetTree().Paused = true;
                    GetNode<Label>("victory").Show();
                }


            }
            else
            {
                GD.Print($"No tile found at {tileCoords}");
            }
        }
    }
}