using Godot;
using System;

public partial class Slime : CharacterBody2D
{

	[Export]
	public float Speed = 24.0f;
    [Export]
    public float damage = 10;
	public NodePath path;
	public NavigationAgent2D _navAgent;
    public float _jumpSpeed = -200.0f;
    [Export]
    public Node2D _target;
    private AnimatedSprite2D _sprite;

    public override void _Ready()
    {
        _sprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
        base._Ready();
        _navAgent = GetNode<NavigationAgent2D>("NavigationAgent2D");
        _sprite.AnimationFinished += idleAnimation;
        _sprite.Play("spawning");

    }

    public override void _Process(double delta)
    {
        base._Process(delta);


        _sprite.FlipH = Velocity.X < 0;
        
    }

    public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Velocity;
		
        // Update the navigation target each frame to follow the player's current position
        _navAgent.TargetPosition = _target.GlobalPosition;

        // Retrieve the next point along the computed path
        Vector2 nextPoint = _navAgent.GetNextPathPosition();

        // Compute direction towards the next point
        if (nextPoint.X > GlobalPosition.X)
        {
            velocity.X = Speed;
        }
        else if (nextPoint.X < GlobalPosition.X) 
        {
            velocity.X = -Speed;
        }

        // Add the gravity.
        if (!IsOnFloor())
        {
            velocity += GetGravity() * (float)delta;
        }
        else
        {
            if (nextPoint.Y < GlobalPosition.Y)
            {
                velocity.Y = _jumpSpeed;
            }
            else
            {
                velocity.Y = 0.0f;

            }
        }


        Velocity = velocity;
		MoveAndSlide();
    }

    private void collidePlayer(Node2D other)
    {
        _sprite.Play("dying");
    }

    private void idleAnimation()
    {
        _sprite.Play("living");
    }


}
